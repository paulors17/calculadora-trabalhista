'use client'

import { useState } from 'react'
import { Calculator, DollarSign, Calendar, AlertCircle, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface RescisaoData {
  salario: number
  mesesTrabalhados: number
  diasTrabalhadosNoMes: number
  motivo: 'pedido' | 'justa' | 'sem_justa' | 'acordo'
  avisoPrevio: 'trabalhado' | 'indenizado' | 'nao_tem'
  fgtsMeses: number
  dependentes: number
  possuiFeriasVencidas: boolean
  diasFeriasVencidas: number
  tirouFeriasNoAno: boolean
  diasFeriasTiradas: number
}

interface RescisaoResult {
  saldoSalario: number
  feriasProporcionais: number
  feriasVencidas: number
  tercoFeriasProporcional: number
  tercoFeriasVencidas: number
  decimoTerceiro: number
  avisoPrevioIndenizado: number
  multaFGTS: number
  fgtsDepositado: number
  totalBruto: number
  totalLiquido: number
  inss: number
  irrf: number
}

export default function RescisaoCalculator() {
  const [formData, setFormData] = useState<RescisaoData>({
    salario: 0,
    mesesTrabalhados: 0,
    diasTrabalhadosNoMes: 30,
    motivo: 'pedido',
    avisoPrevio: 'indenizado',
    fgtsMeses: 0,
    dependentes: 0,
    possuiFeriasVencidas: false,
    diasFeriasVencidas: 0,
    tirouFeriasNoAno: false,
    diasFeriasTiradas: 0
  })

  const [result, setResult] = useState<RescisaoResult | null>(null)
  const [loading, setLoading] = useState(false)

  const handleInputChange = (field: keyof RescisaoData, value: any) => {
    if (typeof value === 'string' && value !== '') {
      const numValue = parseFloat(value)
      if (!isNaN(numValue) && numValue >= 0) {
        setFormData(prev => ({ ...prev, [field]: numValue }))
      }
    } else if (typeof value === 'number') {
      setFormData(prev => ({ ...prev, [field]: value }))
    } else {
      setFormData(prev => ({ ...prev, [field]: value }))
    }
  }

  const calcularRescisao = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/calcular-rescisao', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const data = await response.json()
        setResult(data)
      }
    } catch (error) {
      console.error('Erro ao calcular:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-8">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center mb-4">
            <Calculator className="h-6 w-6 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Cálculo de Rescisão Trabalhista</CardTitle>
          <CardDescription className="text-gray-600">
            Preencha os dados abaixo para calcular sua rescisão com base nas leis de 2025
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Dados Principais */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="salario">Salário Bruto Mensal (R$)</Label>
              <Input
                id="salario"
                type="number"
                value={formData.salario || ''}
                onChange={(e) => handleInputChange('salario', parseFloat(e.target.value) || 0)}
                placeholder="0,00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mesesTrabalhados">Meses Trabalhados</Label>
              <Input
                id="mesesTrabalhados"
                type="number"
                value={formData.mesesTrabalhados || ''}
                onChange={(e) => handleInputChange('mesesTrabalhados', parseInt(e.target.value) || 0)}
                placeholder="0"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="diasTrabalhadosNoMes">Dias Trabalhados no Mês Atual</Label>
              <Input
                id="diasTrabalhadosNoMes"
                type="number"
                min="0"
                max="30"
                value={formData.diasTrabalhadosNoMes || ''}
                onChange={(e) => handleInputChange('diasTrabalhadosNoMes', parseInt(e.target.value) || 0)}
                placeholder="30"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dependentes">Número de Dependentes</Label>
              <Input
                id="dependentes"
                type="number"
                value={formData.dependentes || ''}
                onChange={(e) => handleInputChange('dependentes', parseInt(e.target.value) || 0)}
                placeholder="0"
              />
            </div>
          </div>

          {/* Motivo da Rescisão */}
          <div className="space-y-3">
            <Label>Motivo da Rescisão</Label>
            <RadioGroup
              value={formData.motivo}
              onValueChange={(value) => handleInputChange('motivo', value)}
              className="grid md:grid-cols-2 gap-4"
            >
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="pedido" id="pedido" />
                <Label htmlFor="pedido" className="cursor-pointer">
                  Pedido do Empregado
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="justa" id="justa" />
                <Label htmlFor="justa" className="cursor-pointer">
                  Justa Causa (Empregador)
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="sem_justa" id="sem_justa" />
                <Label htmlFor="sem_justa" className="cursor-pointer">
                  Sem Justa Causa
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="acordo" id="acordo" />
                <Label htmlFor="acordo" className="cursor-pointer">
                  Acordo Coletivo
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Aviso Prévio */}
          <div className="space-y-2">
            <Label>Aviso Prévio</Label>
            <Select
              value={formData.avisoPrevio}
              onValueChange={(value) => handleInputChange('avisoPrevio', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo de aviso prévio" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="trabalhado">Trabalhado</SelectItem>
                <SelectItem value="indenizado">Indenizado</SelectItem>
                <SelectItem value="nao_tem">Não tem aviso prévio</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* FGTS */}
          <div className="space-y-2">
            <Label htmlFor="fgtsMeses">Total de meses com FGTS depositado</Label>
            <Input
              id="fgtsMeses"
              type="number"
              value={formData.fgtsMeses || ''}
              onChange={(e) => handleInputChange('fgtsMeses', parseInt(e.target.value) || 0)}
              placeholder="0"
            />
          </div>

          {/* Férias */}
          <div className="space-y-4">
            <Label>Férias</Label>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="possuiFeriasVencidas"
                checked={formData.possuiFeriasVencidas}
                onChange={(e) => handleInputChange('possuiFeriasVencidas', e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="possuiFeriasVencidas">Possui férias vencidas</Label>
            </div>

            {formData.possuiFeriasVencidas && (
              <div className="space-y-2">
                <Label htmlFor="diasFeriasVencidas">Dias de férias vencidas</Label>
                <Input
                  id="diasFeriasVencidas"
                  type="number"
                  value={formData.diasFeriasVencidas || ''}
                  onChange={(e) => handleInputChange('diasFeriasVencidas', parseInt(e.target.value) || 0)}
                  placeholder="30"
                />
              </div>
            )}

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="tirouFeriasNoAno"
                checked={formData.tirouFeriasNoAno}
                onChange={(e) => handleInputChange('tirouFeriasNoAno', e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="tirouFeriasNoAno">Já tirou férias no período aquisitivo atual</Label>
            </div>

            {formData.tirouFeriasNoAno && (
              <div className="space-y-2">
                <Label htmlFor="diasFeriasTiradas">Dias de férias já tirados</Label>
                <Input
                  id="diasFeriasTiradas"
                  type="number"
                  value={formData.diasFeriasTiradas || ''}
                  onChange={(e) => handleInputChange('diasFeriasTiradas', parseInt(e.target.value) || 0)}
                  placeholder="30"
                />
              </div>
            )}
          </div>

          <Button 
            onClick={calcularRescisao}
            disabled={loading || formData.salario <= 0 || formData.mesesTrabalhados <= 0}
            className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white font-medium py-3"
          >
            {loading ? 'Calculando...' : 'Calcular Rescisão'}
          </Button>
        </CardContent>
      </Card>

      {/* Resultados */}
      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>Resultado do Cálculo</span>
            </CardTitle>
            <CardDescription>
              Valores calculados conforme a legislação trabalhista brasileira
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Verbas Trabalhistas */}
            <div>
              <h3 className="font-semibold text-lg mb-4 flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-blue-500" />
                <span>Verbas Trabalhistas</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>Saldo de Salário:</span>
                  <span className="font-medium">{formatCurrency(result.saldoSalario)}</span>
                </div>
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>Férias Proporcionais:</span>
                  <span className="font-medium">{formatCurrency(result.feriasProporcionais)}</span>
                </div>
                {result.feriasVencidas > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>Férias Vencidas:</span>
                    <span className="font-medium">{formatCurrency(result.feriasVencidas)}</span>
                  </div>
                )}
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>1/3 Férias Proporcional:</span>
                  <span className="font-medium">{formatCurrency(result.tercoFeriasProporcional)}</span>
                </div>
                {result.tercoFeriasVencidas > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>1/3 Férias Vencidas:</span>
                    <span className="font-medium">{formatCurrency(result.tercoFeriasVencidas)}</span>
                  </div>
                )}
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>13º Salário Proporcional:</span>
                  <span className="font-medium">{formatCurrency(result.decimoTerceiro)}</span>
                </div>
                {result.avisoPrevioIndenizado > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>Aviso Prévio Indenizado:</span>
                    <span className="font-medium">{formatCurrency(result.avisoPrevioIndenizado)}</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* FGTS */}
            <div>
              <h3 className="font-semibold text-lg mb-4 flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-green-500" />
                <span>FGTS</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>FGTS Depositado:</span>
                  <span className="font-medium">{formatCurrency(result.fgtsDepositado)}</span>
                </div>
                {result.multaFGTS > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>Multa FGTS (40%):</span>
                    <span className="font-medium">{formatCurrency(result.multaFGTS)}</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Impostos */}
            <div>
              <h3 className="font-semibold text-lg mb-4 flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                <span>Impostos e Deduções</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>INSS:</span>
                  <span className="font-medium">-{formatCurrency(result.inss)}</span>
                </div>
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>IRRF:</span>
                  <span className="font-medium">-{formatCurrency(result.irrf)}</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Total */}
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-6 rounded-lg">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Bruto</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(result.totalBruto)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Líquido</p>
                  <p className="text-3xl font-bold text-emerald-600">{formatCurrency(result.totalLiquido)}</p>
                </div>
              </div>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Atenção:</strong> Este cálculo é uma estimativa baseada nas informações fornecidas. 
                Os valores finais podem variar conforme acordos coletivos, convenções sindicais ou 
                condições específicas do seu contrato de trabalho.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  )
}