'use client'

import { useState } from 'react'
import { Calculator, DollarSign, Calendar, AlertCircle, CheckCircle, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface FeriasData {
  salario: number
  diasFerias: number
  mesesTrabalhados: number
  diasAbono: number
  adiantarPrimeiraParcela: boolean
  possuiDependentes: boolean
  numeroDependentes: number
  outrosDescontos: number
}

interface FeriasResult {
  salarioFerias: number
  tercoConstitucional: number
  abonoPecuniario: number
  totalBruto: number
  inss: number
  irrf: number
  outrosDescontos: number
  totalLiquido: number
  primeiraParcela: number
  segundaParcela: number
}

export default function FeriasCalculator() {
  const [formData, setFormData] = useState<FeriasData>({
    salario: 0,
    diasFerias: 30,
    mesesTrabalhados: 12,
    diasAbono: 0,
    adiantarPrimeiraParcela: false,
    possuiDependentes: false,
    numeroDependentes: 0,
    outrosDescontos: 0
  })

  const [result, setResult] = useState<FeriasResult | null>(null)
  const [loading, setLoading] = useState(false)

  const handleInputChange = (field: keyof FeriasData, value: any) => {
    if (typeof value === 'string' && value !== '') {
      const numValue = parseFloat(value)
      if (!isNaN(numValue) && numValue >= 0) {
        setFormData(prev => ({ ...prev, [field]: numValue }))
      }
    } else if (typeof value === 'number') {
      setFormData(prev => ({ ...prev, [field]: value }))
    } else {
      setFormData(prev => ({ ...prev, [field]: value }))
    }
  }

  const calcularFerias = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/calcular-ferias', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const data = await response.json()
        setResult(data)
      }
    } catch (error) {
      console.error('Erro ao calcular:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-8">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mb-4">
            <Calculator className="h-6 w-6 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Cálculo de Férias</CardTitle>
          <CardDescription className="text-gray-600">
            Planeje suas férias sabendo exatamente quanto vai receber
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Informações Principais */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="salario">Salário Bruto Mensal (R$)</Label>
              <Input
                id="salario"
                type="number"
                value={formData.salario || ''}
                onChange={(e) => handleInputChange('salario', parseFloat(e.target.value) || 0)}
                placeholder="0,00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mesesTrabalhados">Meses Trabalhados no Período</Label>
              <Input
                id="mesesTrabalhados"
                type="number"
                min="1"
                max="12"
                value={formData.mesesTrabalhados || ''}
                onChange={(e) => handleInputChange('mesesTrabalhados', parseInt(e.target.value) || 0)}
                placeholder="12"
              />
            </div>
          </div>

          {/* Dias de Férias */}
          <div className="space-y-3">
            <Label>Quantos dias de férias deseja tirar?</Label>
            <RadioGroup
              value={formData.diasFerias.toString()}
              onValueChange={(value) => handleInputChange('diasFerias', parseInt(value))}
              className="grid md:grid-cols-3 gap-4"
            >
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="30" id="30" />
                <Label htmlFor="30" className="cursor-pointer">
                  30 dias (integral)
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="20" id="20" />
                <Label htmlFor="20" className="cursor-pointer">
                  20 dias
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="15" id="15" />
                <Label htmlFor="15" className="cursor-pointer">
                  15 dias
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Abono Pecuniário */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="temAbono"
                checked={formData.diasAbono > 0}
                onChange={(e) => handleInputChange('diasAbono', e.target.checked ? 10 : 0)}
                className="rounded"
              />
              <Label htmlFor="temAbono" className="cursor-pointer">
                Deseja vender 10 dias de férias (abono pecuniário)?
              </Label>
            </div>

            {formData.diasAbono > 0 && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Você receberá o valor correspondente a 10 dias de férias + 1/3, mas tirará apenas 20 dias de descanso.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Adiantamento */}
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="adiantarPrimeiraParcela"
              checked={formData.adiantarPrimeiraParcela}
              onChange={(e) => handleInputChange('adiantarPrimeiraParcela', e.target.checked)}
              className="rounded"
            />
            <Label htmlFor="adiantarPrimeiraParcela" className="cursor-pointer">
              Deseja adiantar a primeira parcela (metade do valor)?
            </Label>
          </div>

          {/* Dependentes */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="possuiDependentes"
                checked={formData.possuiDependentes}
                onChange={(e) => handleInputChange('possuiDependentes', e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="possuiDependentes" className="cursor-pointer">
                Possui dependentes para dedução de IRRF?
              </Label>
            </div>

            {formData.possuiDependentes && (
              <div className="space-y-2">
                <Label htmlFor="numeroDependentes">Número de Dependentes</Label>
                <Input
                  id="numeroDependentes"
                  type="number"
                  min="0"
                  value={formData.numeroDependentes || ''}
                  onChange={(e) => handleInputChange('numeroDependentes', parseInt(e.target.value) || 0)}
                  placeholder="0"
                />
              </div>
            )}
          </div>

          {/* Outros Descontos */}
          <div className="space-y-2">
            <Label htmlFor="outrosDescontos">Outros Descontos (R$)</Label>
            <Input
              id="outrosDescontos"
              type="number"
              value={formData.outrosDescontos || ''}
              onChange={(e) => handleInputChange('outrosDescontos', parseFloat(e.target.value) || 0)}
              placeholder="0,00"
            />
            <p className="text-sm text-gray-500">
              Ex: adiantamentos, vale-transporte, plano de saúde, etc.
            </p>
          </div>

          <Button 
            onClick={calcularFerias}
            disabled={loading || formData.salario <= 0 || formData.mesesTrabalhados <= 0}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white font-medium py-3"
          >
            {loading ? 'Calculando...' : 'Calcular Férias'}
          </Button>
        </CardContent>
      </Card>

      {/* Resultados */}
      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>Resultado do Cálculo</span>
            </CardTitle>
            <CardDescription>
              Valores calculados conforme a legislação trabalhista brasileira
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Cálculo das Férias */}
            <div>
              <h3 className="font-semibold text-lg mb-4 flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                <span>Cálculo das Férias</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>Salário das Férias ({formData.diasFerias} dias):</span>
                  <span className="font-medium">{formatCurrency(result.salarioFerias)}</span>
                </div>
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>1/3 Constitucional:</span>
                  <span className="font-medium">{formatCurrency(result.tercoConstitucional)}</span>
                </div>
                {result.abonoPecuniario > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>Abono Pecuniário (10 dias):</span>
                    <span className="font-medium">{formatCurrency(result.abonoPecuniario)}</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Impostos */}
            <div>
              <h3 className="font-semibold text-lg mb-4 flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                <span>Impostos e Deduções</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>INSS:</span>
                  <span className="font-medium">-{formatCurrency(result.inss)}</span>
                </div>
                <div className="flex justify-between p-3 bg-gray-50 rounded">
                  <span>IRRF:</span>
                  <span className="font-medium">-{formatCurrency(result.irrf)}</span>
                </div>
                {result.outrosDescontos > 0 && (
                  <div className="flex justify-between p-3 bg-gray-50 rounded">
                    <span>Outros Descontos:</span>
                    <span className="font-medium">-{formatCurrency(result.outrosDescontos)}</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Resumo */}
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-lg">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Bruto</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(result.totalBruto)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Líquido</p>
                  <p className="text-3xl font-bold text-blue-600">{formatCurrency(result.totalLiquido)}</p>
                </div>
              </div>

              {formData.adiantarPrimeiraParcela && (
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Parcelamento</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-3 bg-white rounded border">
                      <p className="text-sm text-gray-600 mb-1">Primeira Parcela (adiantada)</p>
                      <p className="text-xl font-bold text-green-600">{formatCurrency(result.primeiraParcela)}</p>
                    </div>
                    <div className="p-3 bg-white rounded border">
                      <p className="text-sm text-gray-600 mb-1">Segunda Parcela</p>
                      <p className="text-xl font-bold text-blue-600">{formatCurrency(result.segundaParcela)}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Informações Adicionais */}
            <div className="space-y-3">
              <h4 className="font-semibold">Informações Importantes:</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <p>• Você tem direito a {formData.diasFerias} dias de descanso</p>
                {formData.diasAbono > 0 && (
                  <p>• Com o abono pecuniário, você receberá o valor de 10 dias mas tirará 20 dias de folga</p>
                )}
                <p>• O INSS é calculado sobre o total bruto das férias</p>
                <p>• O IRRF só é descontado se o total bruto ultrapassar o limite mensal</p>
                {formData.possuiDependentes && (
                  <p>• Cada dependente reduz R$ 189,59 na base de cálculo do IRRF</p>
                )}
              </div>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Atenção:</strong> Este cálculo é uma estimativa baseada nas informações fornecidas. 
                Os valores finais podem variar conforme acordos coletivos, convenções sindicais ou 
                políticas específicas da sua empresa.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  )
}