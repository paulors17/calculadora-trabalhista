'use client'

import { useState } from 'react'
import { User, Mail, Phone, MessageSquare, Send, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'

interface ContactData {
  nome: string
  email: string
  telefone: string
  tipoServico: string
  urgencia: string
  mensagem: string
  melhorHorario: string
  preferenciaContato: string
}

export default function ContactForm() {
  const [formData, setFormData] = useState<ContactData>({
    nome: '',
    email: '',
    telefone: '',
    tipoServico: '',
    urgencia: 'normal',
    mensagem: '',
    melhorHorario: '',
    preferenciaContato: 'whatsapp'
  })

  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')

  const handleInputChange = (field: keyof ContactData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    setError('')
  }

  const validateForm = () => {
    if (!formData.nome.trim()) {
      setError('Por favor, informe seu nome completo')
      return false
    }
    if (!formData.email.trim()) {
      setError('Por favor, informe seu e-mail')
      return false
    }
    if (!formData.telefone.trim()) {
      setError('Por favor, informe seu telefone')
      return false
    }
    if (!formData.tipoServico) {
      setError('Por favor, selecione o tipo de serviço')
      return false
    }
    if (!formData.mensagem.trim()) {
      setError('Por favor, descreva brevemente seu caso')
      return false
    }
    
    // Validação de e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      setError('Por favor, informe um e-mail válido')
      return false
    }
    
    // Validação de telefone (formato brasileiro)
    const phoneRegex = /^\(?[1-9]{2}\)? ?(?:[2-8]|9[1-9])[0-9]{3}-?[0-9]{4}$/
    const cleanPhone = formData.telefone.replace(/\D/g, '')
    if (cleanPhone.length < 10 || cleanPhone.length > 11) {
      setError('Por favor, informe um telefone válido com DDD')
      return false
    }
    
    return true
  }

  const formatPhone = (value: string) => {
    const cleaned = value.replace(/\D/g, '')
    const match = cleaned.match(/^(\d{2})(\d{5})(\d{4})$/)
    if (match) {
      return `(${match[1]}) ${match[2]}-${match[3]}`
    }
    return value
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }

    setLoading(true)
    setError('')

    try {
      const response = await fetch('/api/contato', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          telefone: formatPhone(formData.telefone),
          dataContato: new Date().toISOString()
        }),
      })

      if (response.ok) {
        setSubmitted(true)
        // Reset form after 3 seconds
        setTimeout(() => {
          setSubmitted(false)
          setFormData({
            nome: '',
            email: '',
            telefone: '',
            tipoServico: '',
            urgencia: 'normal',
            mensagem: '',
            melhorHorario: '',
            preferenciaContato: 'whatsapp'
          })
        }, 3000)
      } else {
        throw new Error('Erro ao enviar contato')
      }
    } catch (error) {
      setError('Ocorreu um erro ao enviar sua mensagem. Por favor, tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <Card className="max-w-2xl mx-auto bg-white/10 backdrop-blur-sm border-white/20">
        <CardContent className="p-8 text-center">
          <div className="mx-auto w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">Mensagem Enviada com Sucesso!</h3>
          <p className="text-emerald-100">
            Um especialista entrará em contato com você em até 24 horas úteis.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="max-w-2xl mx-auto bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-white">
          Solicitar Atendimento Especializado
        </CardTitle>
        <CardDescription className="text-emerald-100">
          Preencha o formulário abaixo e um profissional qualificado entrará em contato
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Dados Pessoais */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome" className="text-white">Nome Completo *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="nome"
                  type="text"
                  value={formData.nome}
                  onChange={(e) => handleInputChange('nome', e.target.value)}
                  placeholder="Seu nome completo"
                  className="pl-10 bg-white/90"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">E-mail *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="seu@email.com"
                  className="pl-10 bg-white/90"
                  required
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="telefone" className="text-white">Telefone com DDD *</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="telefone"
                type="tel"
                value={formData.telefone}
                onChange={(e) => handleInputChange('telefone', e.target.value)}
                placeholder="(11) 98765-4321"
                className="pl-10 bg-white/90"
                required
              />
            </div>
          </div>

          {/* Tipo de Serviço */}
          <div className="space-y-2">
            <Label className="text-white">Tipo de Serviço *</Label>
            <Select
              value={formData.tipoServico}
              onValueChange={(value) => handleInputChange('tipoServico', value)}
            >
              <SelectTrigger className="bg-white/90">
                <SelectValue placeholder="Selecione o tipo de serviço" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rescisao">Auxílio em Rescisão Trabalhista</SelectItem>
                <SelectItem value="ferias">Cálculo e Planejamento de Férias</SelectItem>
                <SelectItem value="verbas">Recuperação de Verbas Trabalhistas</SelectItem>
                <SelectItem value="horas-extra">Cálculo de Horas Extras</SelectItem>
                <SelectItem value="adicional">Adicionais (Insalubridade, Periculosidade)</SelectItem>
                <SelectItem value="dano-moral">Dano Moral Trabalhista</SelectItem>
                <SelectItem value="reconhecimento">Reconhecimento de Vínculo</SelectItem>
                <SelectItem value="outro">Outro Assunto</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Urgência */}
          <div className="space-y-3">
            <Label className="text-white">Nível de Urgência</Label>
            <RadioGroup
              value={formData.urgencia}
              onValueChange={(value) => handleInputChange('urgencia', value)}
              className="grid md:grid-cols-3 gap-4"
            >
              <div className="flex items-center space-x-2 p-3 bg-white/10 rounded-lg border border-white/20">
                <RadioGroupItem value="baixa" id="baixa" />
                <Label htmlFor="baixa" className="text-white cursor-pointer">
                  Baixa
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-white/10 rounded-lg border border-white/20">
                <RadioGroupItem value="normal" id="normal" />
                <Label htmlFor="normal" className="text-white cursor-pointer">
                  Normal
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-white/10 rounded-lg border border-white/20">
                <RadioGroupItem value="alta" id="alta" />
                <Label htmlFor="alta" className="text-white cursor-pointer">
                  Alta
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Preferência de Contato */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Preferência de Contato</Label>
              <Select
                value={formData.preferenciaContato}
                onValueChange={(value) => handleInputChange('preferenciaContato', value)}
              >
                <SelectTrigger className="bg-white/90">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="telefone">Telefone</SelectItem>
                  <SelectItem value="email">E-mail</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="melhorHorario" className="text-white">Melhor Horário para Contato</Label>
              <Input
                id="melhorHorario"
                type="text"
                value={formData.melhorHorario}
                onChange={(e) => handleInputChange('melhorHorario', e.target.value)}
                placeholder="Ex: Segundas após 18h"
                className="bg-white/90"
              />
            </div>
          </div>

          {/* Mensagem */}
          <div className="space-y-2">
            <Label htmlFor="mensagem" className="text-white">Descreva brevemente seu caso *</Label>
            <div className="relative">
              <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Textarea
                id="mensagem"
                value={formData.mensagem}
                onChange={(e) => handleInputChange('mensagem', e.target.value)}
                placeholder="Descreva sua situação, dúvidas ou o que precisa de ajuda..."
                className="pl-10 min-h-[100px] bg-white/90 resize-none"
                required
              />
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <Alert className="bg-red-500/20 border-red-500/50">
              <AlertDescription className="text-white">
                {error}
              </AlertDescription>
            </Alert>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-white text-emerald-700 hover:bg-emerald-50 font-medium py-3"
          >
            {loading ? (
              <span className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-emerald-700 border-t-transparent rounded-full animate-spin" />
                <span>Enviando...</span>
              </span>
            ) : (
              <span className="flex items-center space-x-2">
                <Send className="h-4 w-4" />
                <span>Enviar Solicitação</span>
              </span>
            )}
          </Button>

          {/* Privacy Notice */}
          <p className="text-xs text-emerald-100 text-center">
            Seus dados são confidenciais e serão usados apenas para entrar em contato sobre seu caso. 
            Respeitamos sua privacidade conforme a LGPD.
          </p>
        </form>
      </CardContent>
    </Card>
  )
}