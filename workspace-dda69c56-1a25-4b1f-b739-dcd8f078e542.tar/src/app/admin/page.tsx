'use client'

import { useState, useEffect } from 'react'
import { User, Mail, Phone, MessageSquare, Clock, AlertCircle, CheckCircle, XCircle, RefreshCw, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

interface Contato {
  id: string
  nome: string
  email: string
  telefone: string
  tipoServico: string
  urgencia: string
  mensagem: string
  melhorHorario: string | null
  preferenciaContato: string
  dataContato: string
  status: string
  observacoes: string | null
  createdAt: string
  updatedAt: string
}

export default function AdminPage() {
  const [contatos, setContatos] = useState<Contato[]>([])
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState<string>('todos')
  const [filterUrgencia, setFilterUrgencia] = useState<string>('todos')
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedContato, setSelectedContato] = useState<Contato | null>(null)
  const [observacoes, setObservacoes] = useState('')
  const [updatingStatus, setUpdatingStatus] = useState(false)

  useEffect(() => {
    fetchContatos()
  }, [])

  const fetchContatos = async () => {
    try {
      const response = await fetch('/api/contato')
      if (response.ok) {
        const data = await response.json()
        setContatos(data)
      }
    } catch (error) {
      console.error('Erro ao buscar contatos:', error)
    } finally {
      setLoading(false)
    }
  }

  const updateStatus = async (contatoId: string, newStatus: string) => {
    setUpdatingStatus(true)
    try {
      const response = await fetch(`/api/contato/${contatoId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          status: newStatus,
          observacoes: observacoes.trim() || null 
        }),
      })

      if (response.ok) {
        await fetchContatos()
        setSelectedContato(null)
        setObservacoes('')
      }
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
    } finally {
      setUpdatingStatus(false)
    }
  }

  const filteredContatos = contatos.filter(contato => {
    const matchesStatus = filterStatus === 'todos' || contato.status === filterStatus
    const matchesUrgencia = filterUrgencia === 'todos' || contato.urgencia === filterUrgencia
    const matchesSearch = searchTerm === '' || 
      contato.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contato.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contato.telefone.includes(searchTerm)
    
    return matchesStatus && matchesUrgencia && matchesSearch
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pendente': return 'bg-yellow-100 text-yellow-800'
      case 'contatado': return 'bg-blue-100 text-blue-800'
      case 'concluido': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getUrgenciaColor = (urgencia: string) => {
    switch (urgencia) {
      case 'alta': return 'bg-red-100 text-red-800'
      case 'normal': return 'bg-yellow-100 text-yellow-800'
      case 'baixa': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getTipoServicoLabel = (tipo: string) => {
    const labels: { [key: string]: string } = {
      'rescisao': 'Auxílio em Rescisão',
      'ferias': 'Cálculo de Férias',
      'verbas': 'Recuperação de Verbas',
      'horas-extra': 'Horas Extras',
      'adicional': 'Adicionais',
      'dano-moral': 'Dano Moral',
      'reconhecimento': 'Reconhecimento de Vínculo',
      'outro': 'Outro Assunto'
    }
    return labels[tipo] || tipo
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Carregando contatos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <User className="h-6 w-6 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Área Administrativa</h1>
            </div>
            <Button onClick={fetchContatos} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Atualizar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Estatísticas */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total</p>
                  <p className="text-2xl font-bold text-gray-900">{contatos.length}</p>
                </div>
                <User className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pendentes</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {contatos.filter(c => c.status === 'pendente').length}
                  </p>
                </div>
                <AlertCircle className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Contatados</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {contatos.filter(c => c.status === 'contatado').length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Concluídos</p>
                  <p className="text-2xl font-bold text-green-600">
                    {contatos.filter(c => c.status === 'concluido').length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Filter className="h-5 w-5" />
              <span>Filtros</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="search">Buscar</Label>
                <Input
                  id="search"
                  placeholder="Nome, e-mail ou telefone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="contatado">Contatado</SelectItem>
                    <SelectItem value="concluido">Concluído</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="urgencia">Urgência</Label>
                <Select value={filterUrgencia} onValueChange={setFilterUrgencia}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todas</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="baixa">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchTerm('')
                    setFilterStatus('todos')
                    setFilterUrgencia('todos')
                  }}
                  className="w-full"
                >
                  Limpar Filtros
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Contatos */}
        <Card>
          <CardHeader>
            <CardTitle>Contatos Recebidos</CardTitle>
            <CardDescription>
              {filteredContatos.length} contato{filteredContatos.length !== 1 ? 's' : ''} encontrado{filteredContatos.length !== 1 ? 's' : ''}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredContatos.length === 0 ? (
              <div className="text-center py-12">
                <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Nenhum contato encontrado</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredContatos.map((contato) => (
                  <div key={contato.id} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{contato.nome}</h3>
                          <Badge className={getStatusColor(contato.status)}>
                            {contato.status}
                          </Badge>
                          <Badge className={getUrgenciaColor(contato.urgencia)}>
                            {contato.urgencia}
                          </Badge>
                        </div>
                        <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
                          <div className="flex items-center space-x-2">
                            <Mail className="h-4 w-4" />
                            <span>{contato.email}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4" />
                            <span>{contato.telefone}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4" />
                            <span>{formatDate(contato.createdAt)}</span>
                          </div>
                        </div>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setSelectedContato(contato)
                              setObservacoes(contato.observacoes || '')
                            }}
                          >
                            Ver Detalhes
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Detalhes do Contato</DialogTitle>
                            <DialogDescription>
                              Informações completas e opções de gerenciamento
                            </DialogDescription>
                          </DialogHeader>
                          {selectedContato && (
                            <div className="space-y-6">
                              {/* Informações Básicas */}
                              <div>
                                <h4 className="font-semibold mb-3">Informações do Cliente</h4>
                                <div className="grid md:grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <span className="font-medium">Nome:</span> {selectedContato.nome}
                                  </div>
                                  <div>
                                    <span className="font-medium">E-mail:</span> {selectedContato.email}
                                  </div>
                                  <div>
                                    <span className="font-medium">Telefone:</span> {selectedContato.telefone}
                                  </div>
                                  <div>
                                    <span className="font-medium">Preferência:</span> {selectedContato.preferenciaContato}
                                  </div>
                                  {selectedContato.melhorHorario && (
                                    <div className="md:col-span-2">
                                      <span className="font-medium">Melhor horário:</span> {selectedContato.melhorHorario}
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Informações do Serviço */}
                              <div>
                                <h4 className="font-semibold mb-3">Informações do Serviço</h4>
                                <div className="grid md:grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <span className="font-medium">Tipo:</span> {getTipoServicoLabel(selectedContato.tipoServico)}
                                  </div>
                                  <div>
                                    <span className="font-medium">Urgência:</span> {selectedContato.urgencia}
                                  </div>
                                </div>
                              </div>

                              {/* Mensagem */}
                              <div>
                                <h4 className="font-semibold mb-3">Mensagem do Cliente</h4>
                                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                                  {selectedContato.mensagem}
                                </p>
                              </div>

                              {/* Observações */}
                              <div>
                                <Label htmlFor="observacoes">Observações</Label>
                                <Textarea
                                  id="observacoes"
                                  value={observacoes}
                                  onChange={(e) => setObservacoes(e.target.value)}
                                  placeholder="Adicione observações sobre este contato..."
                                  className="mt-2"
                                />
                              </div>

                              {/* Ações */}
                              <div className="flex space-x-3">
                                <Button
                                  onClick={() => updateStatus(selectedContato.id, 'contatado')}
                                  disabled={updatingStatus}
                                  variant="outline"
                                >
                                  <Clock className="h-4 w-4 mr-2" />
                                  Marcar como Contatado
                                </Button>
                                <Button
                                  onClick={() => updateStatus(selectedContato.id, 'concluido')}
                                  disabled={updatingStatus}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Marcar como Concluído
                                </Button>
                              </div>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      <p><strong>Serviço:</strong> {getTipoServicoLabel(contato.tipoServico)}</p>
                      <p className="mt-1 line-clamp-2">{contato.mensagem}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}