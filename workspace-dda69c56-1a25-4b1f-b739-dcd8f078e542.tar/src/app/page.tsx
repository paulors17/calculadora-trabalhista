'use client'

import { useState } from 'react'
import { Calculator, Calendar, DollarSign, Shield, TrendingUp, Users, CheckCircle, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import RescisaoCalculator from '@/components/RescisaoCalculator'
import FeriasCalculator from '@/components/FeriasCalculator'
import ContactForm from '@/components/ContactForm'

export default function Home() {
  const [activeCalculator, setActiveCalculator] = useState<'rescisao' | 'ferias' | null>(null)

  if (activeCalculator === 'rescisao') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="outline" 
            onClick={() => setActiveCalculator(null)}
            className="mb-6"
          >
            ← Voltar
          </Button>
          <RescisaoCalculator />
        </div>
      </div>
    )
  }

  if (activeCalculator === 'ferias') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="outline" 
            onClick={() => setActiveCalculator(null)}
            className="mb-6"
          >
            ← Voltar
          </Button>
          <FeriasCalculator />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-2 rounded-lg">
                <Calculator className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Calculadora Trabalhista 2025</h1>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Shield className="h-4 w-4" />
              <span>Atualizado com as leis de 2025</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Seus Direitos <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-600">Calculados com Precisão</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            "Conhecimento é poder. Calcule sua rescisão ou férias com base nas leis trabalhistas mais recentes e garanta o que é seu por direito."
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <div className="flex items-center justify-center space-x-2 text-emerald-600">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Cálculos 100% atualizados</span>
            </div>
            <div className="flex items-center justify-center space-x-2 text-emerald-600">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Baseado na CLT 2025</span>
            </div>
            <div className="flex items-center justify-center space-x-2 text-emerald-600">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Resultados instantâneos</span>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator Cards */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Rescisão Card */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto w-16 h-16 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <DollarSign className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Cálculo de Rescisão</CardTitle>
                <CardDescription className="text-gray-600 mt-2">
                  "Saiba exatamente quanto você tem a receber ao encerrar seu contrato de trabalho"
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Saldo de salário</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Férias proporcionais + 1/3</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>13º salário proporcional</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Multa do FGTS (40% ou 20%)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Aviso prévio indenizado</span>
                  </div>
                </div>
                <Button 
                  onClick={() => setActiveCalculator('rescisao')}
                  className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white font-medium py-3"
                >
                  Calcular Rescisão
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>

            {/* Férias Card */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Cálculo de Férias</CardTitle>
                <CardDescription className="text-gray-600 mt-2">
                  "Planeje suas férias sabendo exatamente quanto você vai receber"
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Férias integrais (30 dias)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Adicional de 1/3 constitucional</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Abono pecuniário (opcional)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Primeira parcela adiantada</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Desconto de impostos</span>
                  </div>
                </div>
                <Button 
                  onClick={() => setActiveCalculator('ferias')}
                  className="w-full bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white font-medium py-3"
                >
                  Calcular Férias
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Por que escolher nossa calculadora?
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              "Ferramenta desenvolvida por especialistas para garantir que você receba exatamente o que a lei garante"
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-emerald-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Precisão Absoluta</h4>
              <p className="text-gray-600 text-sm">
                Cálculos baseados nas atualizações da CLT e legislação vigente em 2025
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Interface Intuitiva</h4>
              <p className="text-gray-600 text-sm">
                Design pensado para facilitar sua vida, sem complicações ou jargões técnicos
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Segurança e Confiança</h4>
              <p className="text-gray-600 text-sm">
                Seus dados são processados localmente, garantindo total privacidade e segurança
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-emerald-600 to-teal-700">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-white mb-4">
              Fale com um Profissional Especializado
            </h3>
            <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
              "Precisa de ajuda com seu caso? Deixe seus dados e um especialista em direito trabalhista entrará em contato"
            </p>
          </div>
          <ContactForm />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <p className="text-gray-400 mb-2">
            "Conhecer seus direitos é o primeiro passo para exercê-los"
          </p>
          <p className="text-sm text-gray-500 mb-4">
            © 2025 Calculadora Trabalhista. Atualizado com as leis trabalhistas brasileiras.
          </p>
          <div className="flex justify-center space-x-4 text-xs text-gray-600">
            <a href="/admin" className="hover:text-gray-400 transition-colors">
              Área Administrativa
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}