import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const { status, observacoes } = await request.json()

    // Validar status
    const validStatuses = ['pendente', 'contatado', 'concluido']
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json(
        { error: 'Status inválido' },
        { status: 400 }
      )
    }

    // Atualizar contato
    const contato = await db.contato.update({
      where: { id },
      data: {
        ...(status && { status }),
        ...(observacoes !== undefined && { observacoes }),
        updatedAt: new Date()
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Contato atualizado com sucesso',
      contato
    })

  } catch (error) {
    console.error('Erro ao atualizar contato:', error)
    return NextResponse.json(
      { error: 'Erro ao atualizar contato' },
      { status: 500 }
    )
  }
}