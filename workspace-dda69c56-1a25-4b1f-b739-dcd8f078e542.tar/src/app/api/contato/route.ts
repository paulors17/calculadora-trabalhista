import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface ContatoData {
  nome: string
  email: string
  telefone: string
  tipoServico: string
  urgencia: string
  mensagem: string
  melhorHorario: string
  preferenciaContato: string
  dataContato: string
}

export async function POST(request: NextRequest) {
  try {
    const data: ContatoData = await request.json()

    // Validação básica
    if (!data.nome || !data.email || !data.telefone || !data.tipoServico || !data.mensagem) {
      return NextResponse.json(
        { error: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      )
    }

    // Validação de e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(data.email)) {
      return NextResponse.json(
        { error: 'E-mail inválido' },
        { status: 400 }
      )
    }

    // Salvar no banco de dados
    const contato = await db.contato.create({
      data: {
        nome: data.nome.trim(),
        email: data.email.trim().toLowerCase(),
        telefone: data.telefone.trim(),
        tipoServico: data.tipoServico,
        urgencia: data.urgencia || 'normal',
        mensagem: data.mensagem.trim(),
        melhorHorario: data.melhorHorario?.trim() || null,
        preferenciaContato: data.preferenciaContato || 'whatsapp',
        dataContato: new Date(data.dataContato),
        status: 'pendente'
      }
    })

    // Aqui você poderia adicionar:
    // 1. Envio de e-mail de confirmação para o cliente
    // 2. Envio de notificação para o profissional
    // 3. Integração com sistemas de CRM
    // 4. Envio de WhatsApp (usando APIs como Twilio, Z-API, etc.)

    return NextResponse.json({
      success: true,
      message: 'Contato registrado com sucesso',
      id: contato.id
    })

  } catch (error) {
    console.error('Erro ao salvar contato:', error)
    return NextResponse.json(
      { error: 'Erro ao processar sua solicitação' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // Buscar todos os contatos (para área administrativa)
    const contatos = await db.contato.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(contatos)

  } catch (error) {
    console.error('Erro ao buscar contatos:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar contatos' },
      { status: 500 }
    )
  }
}