import { NextRequest, NextResponse } from 'next/server'

interface FeriasData {
  salario: number
  diasFerias: number
  mesesTrabalhados: number
  diasAbono: number
  adiantarPrimeiraParcela: boolean
  possuiDependentes: boolean
  numeroDependentes: number
  outrosDescontos: number
}

interface FeriasResult {
  salarioFerias: number
  tercoConstitucional: number
  abonoPecuniario: number
  totalBruto: number
  inss: number
  irrf: number
  outrosDescontos: number
  totalLiquido: number
  primeiraParcela: number
  segundaParcela: number
}

// Tabelas de 2025
const INSS_TABLE_2025 = [
  { min: 0, max: 1412.00, alíquota: 0.075, deducao: 0 },
  { min: 1412.01, max: 2666.68, alíquota: 0.09, deducao: 21.18 },
  { min: 2666.69, max: 4000.03, alíquota: 0.12, deducao: 101.18 },
  { min: 4000.04, max: 7786.02, alíquota: 0.14, deducao: 181.18 },
  { min: 7786.03, max: Infinity, alíquota: 0.14, deducao: 181.18 } // Teto
]

const IRRF_TABLE_2025 = [
  { min: 0, max: 2259.20, alíquota: 0, deducao: 0 },
  { min: 2259.21, max: 2826.65, alíquota: 0.075, deducao: 169.44 },
  { min: 2826.66, max: 3751.05, alíquota: 0.15, deducao: 381.44 },
  { min: 3751.06, max: 4664.68, alíquota: 0.225, deducao: 662.77 },
  { min: 4664.69, max: Infinity, alíquota: 0.275, deducao: 896.00 }
]

const DEPENDENTE_DEDUCTION_2025 = 189.59

function calcularINSS(base: number): number {
  for (const faixa of INSS_TABLE_2025) {
    if (base >= faixa.min && base <= faixa.max) {
      return Math.min(base * faixa.alíquota - faixa.deducao, 908.36) // Teto INSS 2025
    }
  }
  return 0
}

function calcularIRRF(base: number, dependentes: number): number {
  const baseComDeducoes = Math.max(0, base - (dependentes * DEPENDENTE_DEDUCTION_2025))
  
  for (const faixa of IRRF_TABLE_2025) {
    if (baseComDeducoes >= faixa.min && baseComDeducoes <= faixa.max) {
      return Math.max(0, baseComDeducoes * faixa.alíquota - faixa.deducao)
    }
  }
  return 0
}

export async function POST(request: NextRequest) {
  try {
    const data: FeriasData = await request.json()

    // Salário das férias (proporcional aos dias)
    const salarioFerias = (data.salario / 30) * data.diasFerias

    // 1/3 constitucional sobre o salário das férias
    const tercoConstitucional = salarioFerias / 3

    // Abono pecuniário (venda de 10 dias de férias)
    let abonoPecuniario = 0
    if (data.diasAbono > 0) {
      const valorDiaFerias = data.salario / 30
      abonoPecuniario = valorDiaFerias * data.diasAbono + (valorDiaFerias * data.diasAbono) / 3
    }

    // Total bruto
    const totalBruto = salarioFerias + tercoConstitucional + abonoPecuniario

    // Cálculo de impostos
    const inss = calcularINSS(totalBruto)
    const dependentes = data.possuiDependentes ? data.numeroDependentes : 0
    const irrf = calcularIRRF(totalBruto, dependentes)

    // Total líquido
    const totalLiquido = totalBruto - inss - irrf - data.outrosDescontos

    // Parcelamento (se adiantar primeira parcela)
    let primeiraParcela = 0
    let segundaParcela = 0
    
    if (data.adiantarPrimeiraParcela) {
      primeiraParcela = totalLiquido / 2
      segundaParcela = totalLiquido / 2
    }

    const result: FeriasResult = {
      salarioFerias,
      tercoConstitucional,
      abonoPecuniario,
      totalBruto,
      inss,
      irrf,
      outrosDescontos: data.outrosDescontos,
      totalLiquido,
      primeiraParcela,
      segundaParcela
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Erro ao calcular férias:', error)
    return NextResponse.json(
      { error: 'Erro ao processar o cálculo das férias' },
      { status: 500 }
    )
  }
}