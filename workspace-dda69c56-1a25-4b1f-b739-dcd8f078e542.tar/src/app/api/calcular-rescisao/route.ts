import { NextRequest, NextResponse } from 'next/server'

interface RescisaoData {
  salario: number
  mesesTrabalhados: number
  diasTrabalhadosNoMes: number
  motivo: 'pedido' | 'justa' | 'sem_justa' | 'acordo'
  avisoPrevio: 'trabalhado' | 'indenizado' | 'nao_tem'
  fgtsMeses: number
  dependentes: number
  possuiFeriasVencidas: boolean
  diasFeriasVencidas: number
  tirouFeriasNoAno: boolean
  diasFeriasTiradas: number
}

interface RescisaoResult {
  saldoSalario: number
  feriasProporcionais: number
  feriasVencidas: number
  tercoFeriasProporcional: number
  tercoFeriasVencidas: number
  decimoTerceiro: number
  avisoPrevioIndenizado: number
  multaFGTS: number
  fgtsDepositado: number
  totalBruto: number
  totalLiquido: number
  inss: number
  irrf: number
}

// Tabelas de 2025
const INSS_TABLE_2025 = [
  { min: 0, max: 1412.00, alíquota: 0.075, deducao: 0 },
  { min: 1412.01, max: 2666.68, alíquota: 0.09, deducao: 21.18 },
  { min: 2666.69, max: 4000.03, alíquota: 0.12, deducao: 101.18 },
  { min: 4000.04, max: 7786.02, alíquota: 0.14, deducao: 181.18 },
  { min: 7786.03, max: Infinity, alíquota: 0.14, deducao: 181.18 } // Teto
]

const IRRF_TABLE_2025 = [
  { min: 0, max: 2259.20, alíquota: 0, deducao: 0 },
  { min: 2259.21, max: 2826.65, alíquota: 0.075, deducao: 169.44 },
  { min: 2826.66, max: 3751.05, alíquota: 0.15, deducao: 381.44 },
  { min: 3751.06, max: 4664.68, alíquota: 0.225, deducao: 662.77 },
  { min: 4664.69, max: Infinity, alíquota: 0.275, deducao: 896.00 }
]

const DEPENDENTE_DEDUCTION_2025 = 189.59

function calcularINSS(base: number): number {
  for (const faixa of INSS_TABLE_2025) {
    if (base >= faixa.min && base <= faixa.max) {
      return Math.min(base * faixa.alíquota - faixa.deducao, 908.36) // Teto INSS 2025
    }
  }
  return 0
}

function calcularIRRF(base: number, dependentes: number): number {
  const baseComDeducoes = Math.max(0, base - (dependentes * DEPENDENTE_DEDUCTION_2025))
  
  for (const faixa of IRRF_TABLE_2025) {
    if (baseComDeducoes >= faixa.min && baseComDeducoes <= faixa.max) {
      return Math.max(0, baseComDeducoes * faixa.alíquota - faixa.deducao)
    }
  }
  return 0
}

function calcularAvisoPrevioIndenizado(salario: number, mesesTrabalhados: number): number {
  // Aviso prévio básico de 30 dias + 3 dias por ano acima do primeiro ano
  const anosCompletos = Math.floor(mesesTrabalhados / 12)
  const diasAdicionais = Math.min(anosCompletos * 3, 60) // Máximo de 60 dias adicionais
  const totalDias = 30 + diasAdicionais
  
  return (salario / 30) * totalDias
}

export async function POST(request: NextRequest) {
  try {
    const data: RescisaoData = await request.json()

    // Saldo de salário
    const saldoSalario = (data.salario / 30) * data.diasTrabalhadosNoMes

    // Férias proporcionais
    const feriasProporcionais = (data.salario / 12) * data.mesesTrabalhados
    const tercoFeriasProporcional = feriasProporcionais / 3

    // Férias vencidas
    let feriasVencidas = 0
    let tercoFeriasVencidas = 0
    
    if (data.possuiFeriasVencidas && data.diasFeriasVencidas > 0) {
      feriasVencidas = (data.salario / 30) * data.diasFeriasVencidas
      tercoFeriasVencidas = feriasVencidas / 3
    }

    // Férias do período atual (se já tirou algumas)
    let feriasPeriodoAtual = 0
    let tercoFeriasPeriodoAtual = 0
    
    if (data.tirouFeriasNoAno && data.diasFeriasTiradas > 0) {
      const diasRestantes = Math.max(0, 30 - data.diasFeriasTiradas)
      if (diasRestantes > 0) {
        feriasPeriodoAtual = (data.salario / 30) * diasRestantes
        tercoFeriasPeriodoAtual = feriasPeriodoAtual / 3
      }
    }

    // 13º salário proporcional
    const decimoTerceiro = (data.salario / 12) * data.mesesTrabalhados

    // Aviso prévio indenizado
    let avisoPrevioIndenizado = 0
    if (data.avisoPrevio === 'indenizado') {
      avisoPrevioIndenizado = calcularAvisoPrevioIndenizado(data.salario, data.mesesTrabalhados)
    }

    // FGTS depositado (8% do salário)
    const fgtsDepositado = data.salario * 0.08 * data.fgtsMeses

    // Multa do FGTS
    let multaFGTS = 0
    if (data.motivo === 'sem_justa') {
      multaFGTS = fgtsDepositado * 0.4 // 40%
    } else if (data.motivo === 'acordo') {
      multaFGTS = fgtsDepositado * 0.2 // 20%
    }

    // Total bruto
    const totalBruto = 
      saldoSalario +
      feriasProporcionais +
      feriasVencidas +
      feriasPeriodoAtual +
      tercoFeriasProporcional +
      tercoFeriasVencidas +
      tercoFeriasPeriodoAtual +
      decimoTerceiro +
      avisoPrevioIndenizado

    // Cálculo de impostos
    const inss = calcularINSS(totalBruto)
    const irrf = calcularIRRF(totalBruto, data.dependentes)

    // Total líquido
    const totalLiquido = totalBruto - inss - irrf

    const result: RescisaoResult = {
      saldoSalario,
      feriasProporcionais,
      feriasVencidas,
      tercoFeriasProporcional,
      tercoFeriasVencidas,
      decimoTerceiro,
      avisoPrevioIndenizado,
      multaFGTS,
      fgtsDepositado,
      totalBruto,
      totalLiquido,
      inss,
      irrf
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Erro ao calcular rescisão:', error)
    return NextResponse.json(
      { error: 'Erro ao processar o cálculo da rescisão' },
      { status: 500 }
    )
  }
}